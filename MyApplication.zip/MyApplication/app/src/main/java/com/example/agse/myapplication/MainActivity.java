package com.example.agse.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText editUername;
    private EditText editPassword;
    private Button btnLogin;
    private TextView txtStatus;
    String username,pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initUI();
    }

    private void initUI(){
        editUername = (EditText)findViewById(R.id.editUsername);
        editUername.getText();
        editPassword = (EditText)findViewById(R.id.editPassword);
        editPassword.getText();
        btnLogin = (Button) findViewById(R.id.btnlogin);

        btnLogin.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                if(v == btnLogin){
                    if(editUername.getText().toString().equals(username) && editPassword.getText().toString().equals(pass)){
                        txtStatus.setText("Login Berhasil");
                    }else{
                        txtStatus.setText("Login Gagal");
                    }
                }
            }
        });
        txtStatus = (TextView) findViewById(R.id.txtStatus);

        username ="agung";
        pass ="agung";
    }
}
